const max = 15;
const min = 0;

for ( let i = 0; i < max; i++ ) {
	console.log(i);
}